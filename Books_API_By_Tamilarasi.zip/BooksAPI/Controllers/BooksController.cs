﻿using BooksAPI.Models;
using BooksAPI.Repository;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Data;
using System.Text.Json;

namespace BooksAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BooksController : ControllerBase
    {

        #region Variable Declartion and Initialization

        private readonly IBooksRepository _companyRepo;

        //Dependancy Injection
        public BooksController(IBooksRepository companyRepo)
        {
            _companyRepo = companyRepo;
        }

        #endregion

        #region Get all the books list from database

        [HttpGet("GetAll-Books")]
        public IActionResult GetAllbooks()
        {
            try

            {
                Books objModel = new Books();
                objModel.Mode = "ALL";
                var result = _companyRepo.GetAllBooksDetails(objModel);
                var jsonresult = JsonSerializer.Serialize(result);
                return Ok(jsonresult);
               
            }
            catch (Exception ex)
            {
                return Ok("Exception occured."+ex.Message.ToString());
            }

        }
        #endregion

        #region Get list of books in the order of Publisher,Author,Title

        // sorting of Publisher,Author,Title

        [HttpPost("Get-Sorted-Publisher-Author-Title")]
        public IActionResult GetSortedList(Books ObjModel)
        {
            try

            {
                var result = _companyRepo.GetAllBooksDetails(ObjModel);
                var jsonresult = JsonSerializer.Serialize(result);
                return Ok(jsonresult);

            }
            catch (Exception ex)
            {
                return Ok("Exception occured." + ex.Message.ToString());
            }

        }
        #endregion

        #region Get list of books by passing inputs of Publisher and Title

        // Filter by Publisher and Title

        [HttpPost("Get-SortedBy-Publisher-Title")]
        public IActionResult GetBooksSortedByFields(Books ObjModel)
        {
            try

            {
                var result = _companyRepo.GetAllBooksDetails(ObjModel);
                var jsonresult = JsonSerializer.Serialize(result);
                return Ok(jsonresult);

            }
            catch (Exception ex)
            {
                return Ok("Exception occured." + ex.Message.ToString());
            }

        }
        #endregion

        #region Get total price of all the books

        [HttpPost("Get-TotalPrice")]
        public IActionResult GetTotalPrice(Books ObjModel)
        {
            try

            {
                var result = _companyRepo.GetAllBooksDetails(ObjModel);
                var jsonresult = JsonSerializer.Serialize(result);
                return Ok(jsonresult);

            }
            catch (Exception ex)
            {
                return Ok("Exception occured." + ex.Message.ToString());
            }

        }

        #endregion

        #region Bulk Data insert at one DB call

        // SQL BulkCopy Implementation

        [HttpPost("Bulk-DataInsert")]
        public IActionResult BulkInsert()
        {
            try

            {
                FileStream fileStream = new FileStream(@"C:\Users\Admin\Documents\Tamil\testFile.txt", FileMode.Open);
                List<Citation> BooksList = new List<Citation>();
                using (StreamReader reader = new StreamReader(fileStream))
                {
                    string line = "";
                    while ((line = reader.ReadLine()) != null)
                    {
                        //print line
                        //Console.WriteLine(line);                        
                        Citation ObjModel = new Citation();
                        string[] textpart = line.Split('|');
                        ObjModel.Publisher = textpart[0];
                        ObjModel.Title = textpart[1];
                        ObjModel.AuthorFirstName = textpart[2];
                        ObjModel.AuthorLastName = textpart[3];
                        ObjModel.Price = Convert.ToDecimal(textpart[4]);
                        ObjModel.CreatedBy = textpart[9];

                        string TitleOfContainer = textpart[5];
                        string PublishedYear = textpart[6];
                        string LocationPageNumber = textpart[7];
                        string URL= textpart[8];

                        string MLACitation= "("+textpart[3] + " , " + textpart[2]+") , '"+ textpart[1] + "' , " + TitleOfContainer+ " , " + textpart[0]+" , "+ PublishedYear+ " , " + LocationPageNumber;
                        string Chicagocitation = "(" + textpart[3] + " , " + textpart[2] + ") , '" + textpart[1] + "' , " + PublishedYear + " , " + LocationPageNumber+" , "+URL;

                        ObjModel.MLACitation = MLACitation;
                        ObjModel.ChicagoCitation = Chicagocitation;

                        BooksList.Add(ObjModel);

                    }

                }
                var result = _companyRepo.BulkDataInsert(BooksList);
                var jsonresult = JsonSerializer.Serialize(result);
                return Ok(jsonresult);

            }
            catch (Exception ex)
            {
                return Ok("Exception occured." + ex.Message.ToString());
            }

        }

        #endregion

    }
}
