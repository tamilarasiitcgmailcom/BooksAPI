﻿using BooksAPI.Context;
using BooksAPI.Models;
using Dapper;
using FastMember;
using Microsoft.Data.SqlClient;
using Newtonsoft.Json;
using System.Data;
using System.Reflection;
using System.Security.Cryptography;
using static Dapper.SqlMapper;

namespace BooksAPI.Repository
{
    public class BooksRepository: IBooksRepository
    {
        #region Variable Declartion and Initialization

        //Dependancy Injection

        private readonly DapperContext _context;
        public BooksRepository(DapperContext context)
        {
            _context = context;
        }
        #endregion

        #region Do all the operations of Books data
        public List<dynamic> GetAllBooksDetails(Books objmodel)
        {
            using (var connection = _context.CreateConnection())
            {
                DynamicParameters parameters = new();
                var data = JsonConvert.SerializeObject(objmodel);
                var deserialize = JsonConvert.DeserializeObject<Dictionary<string, object>>(data)!;
                foreach (var item in deserialize)
                {
                    parameters.Add($"{item.Key}", item.Value);
                }
                var result = connection.Query(sql: "spBooks_BooksDetailsMaintainance", param: parameters, commandType: CommandType.StoredProcedure);
                List<dynamic> list = result.ToList();
                return list;
            }
        }

        #endregion

        #region SQL BulkCopy Implementation
        public string BulkDataInsert(List<Citation> lstBooks)
        {
            using (var sqlCopy = new SqlBulkCopy(_context._connectionString))
            {
                sqlCopy.DestinationTableName = "[tbl_Books]";
                sqlCopy.BatchSize = 500;

                //map property index to column index in table. in database table the first column is the identitycolumn
                sqlCopy.ColumnMappings.Add(0, 1);
                sqlCopy.ColumnMappings.Add(1, 2);
                sqlCopy.ColumnMappings.Add(2, 3);
                sqlCopy.ColumnMappings.Add(3, 4);
                sqlCopy.ColumnMappings.Add(4, 5);
                sqlCopy.ColumnMappings.Add(5, 7);
                sqlCopy.ColumnMappings.Add(6, 8);
                sqlCopy.ColumnMappings.Add(7, 9);

                var records = lstBooks.Select(obj => new { col1 = obj.Title, col2 = obj.AuthorLastName, col3 = obj.AuthorFirstName, col4 = obj.Price, col5 = obj.Publisher, col7 = obj.MLACitation, col8 = obj.ChicagoCitation, col9 = obj.CreatedBy });

                using (var reader = ObjectReader.Create(records, new[] { "col1", "col2", "col3", "col4", "col5", "col7", "col8", "col9" }))
                {
                   sqlCopy.WriteToServer(reader);
                }
                return "Success";
            }
        }

        #endregion

    }
}
