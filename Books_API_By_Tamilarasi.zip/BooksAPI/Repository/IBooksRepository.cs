﻿using BooksAPI.Models;
using Dapper;
using System.Data;
using static Dapper.SqlMapper;

namespace BooksAPI.Repository
{
    public interface IBooksRepository
    {
        // To Manage all books data
        List<dynamic> GetAllBooksDetails(Books objModel);

        // To Insert Bulk Data
        string BulkDataInsert(List<Citation> lstBooks);
    }
}
