﻿using Microsoft.Data.SqlClient;
using System.Data;

namespace BooksAPI.Context
{
    public class DapperContext
    {
        # region Get Connection string from config file

        //Dependancy Injection

        private readonly IConfiguration _configuration;
        public readonly string _connectionString;      
               
        public DapperContext(IConfiguration configuration)
        {
            _configuration = configuration;
            _connectionString = _configuration.GetConnectionString("SqlConnection");
        }
        
        //connection Establish
        public IDbConnection CreateConnection() => new SqlConnection(_connectionString);

        #endregion
    }
}
