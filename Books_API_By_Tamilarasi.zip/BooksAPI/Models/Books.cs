﻿namespace BooksAPI.Models
{

    # region parameters of Books data

    // parameters of Books data
    public class Books
    {
        public string Publisher { get; set; }
        public string Title { get; set; }
        public string AuthorLastName { get; set; }
        public string AuthorFirstName { get; set; }
        public decimal Price { get; set; }
        public string Mode { get; set; }        
        
    }
    public class Citation:Books
    {
        public string MLACitation { get; set; }
        public string ChicagoCitation { get; set; }
        public string CreatedBy { get; set; }
    }

    #endregion
}
